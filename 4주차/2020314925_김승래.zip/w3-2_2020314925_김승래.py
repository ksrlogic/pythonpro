
real_id = "kimSeungRae"
real_password = "12341234"

input_id = input("아이디: ")

trynum=0
while trynum < 3:
    if input_id == real_id:
        print("아이디 일치")
        input_id = "corrected"
    elif input_id == "corrected":
        print("다시")
    else:
        print("아아디 불일치")
        break
    input_password = input("패스워드: ")
    if input_password == real_password:
        print('비밀번호 일치')
        break
    else:
        trynum +=1
        if trynum == 3:
            print('비밀번호 시도횟수 3회 초과')
            break
        else:
            print('비밀번호 불일치')

