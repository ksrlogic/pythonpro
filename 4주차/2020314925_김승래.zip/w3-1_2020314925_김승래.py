result = 0
i = 1
while i < 100:
    if i % 3 == 0:
        result+= i
        if i % 30 == 0 :
            print(i)
        else:
            print(i, end= " ")
    i += 1

print("\n=> 3의 배수의 합계:", result)